class Customer{
String name;

Customer(String name){
this.name=name;
}

void displayCustomerName(){
System.out.println("The customer is "+ this.name);
}

public static void main(String args[]){
Customer c=new Customer("VerizonUser");
c.displayCustomerName();
}
}
