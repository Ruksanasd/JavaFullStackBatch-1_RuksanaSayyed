package com.example.producerapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
