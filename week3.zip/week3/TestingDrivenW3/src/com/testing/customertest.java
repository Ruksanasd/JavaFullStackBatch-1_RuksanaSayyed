package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class customertest {

	@Test
	void test() {
		Customer c=new Customer();
		assertEquals(c.getBalance(),1000);
		//fail("Not yet implemented");
	}

}
