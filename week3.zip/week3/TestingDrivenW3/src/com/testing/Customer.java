package com.testing;

public class Customer {
	
	public Integer getBalance() {
		// TODO Auto-generated method stub
		return 1000;
	}

}
