package com.verizon.model;

public class Plan {
	Integer Id;
	String name;
	Integer age;
	
	
	public Plan() {
		super();
	}

	public Plan(Integer id, String name, Integer age) {
		super();
		Id = id;
		this.name = name;
		this.age = age;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Plan [Id=" + Id + ", name=" + name + ", age=" + age + "]";
	}

}
