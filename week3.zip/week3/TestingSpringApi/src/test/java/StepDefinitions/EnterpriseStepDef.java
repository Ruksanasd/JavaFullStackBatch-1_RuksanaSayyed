package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.cucumber.java.en.Then;


public class EnterpriseStepDef {
	public WebDriver driver;
	public Alert alert;
    @Given("the user is on Main page and click Enterprise Customer button")
    public void user_on_main_page_and_click_enterprise_customer_button() {
    	WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Enterprise Customer")).click();
    }

    @When("the user fills the details and click Add Customer button")
    public void user_fills_details_and_click_add_customer_button() {
    	driver.findElement(By.id("customerId")).sendKeys("5");
		wait(1000);
		driver.findElement(By.id("companyName")).sendKeys("sbi");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[1]/div/button")).click();
    }

    @Then("validate Customer added successfully")
    public void validate_customer_added_successfully() {
    	alert = driver.switchTo().alert();
    	String actResult = alert.getText();
    	Assert.assertEquals(actResult, "Customer added successfully");
    	wait(3000);
    	alert.accept();
    }

    @When("the user fills the details and click Update Customer button")
    public void user_fills_details_and_click_update_customer_button() {
    	driver.findElement(By.id("updateCustomerId")).sendKeys("5");
		wait(1000);
		driver.findElement(By.id("updateCompanyName")).sendKeys("sbibank");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[2]/div/button")).click();
    	
    }

    @Then("validate Customer updated successfully")
    public void validate_customer_updated_successfully() {
    	alert = driver.switchTo().alert();
    	String actResult = alert.getText();
    	Assert.assertEquals(actResult, "Customer updated successfully");
    	wait(3000);
    	alert.accept();
    }

    @When("the user fills the details and click Get Customer button")
    public void user_fills_details_and_click_get_customer_button() {
    	driver.findElement(By.id("getCustomerId")).sendKeys("5");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[3]/div/button")).click();
    	
    }

    @Then("validate Customer Details Fetched Successfully")
    public void validate_customer_details_fetched_successfully() {
    	driver.findElement(By.id("customerList"));
		wait(1000);
    }

    @When("the user fills the details and click Get All Customer button")
    public void user_fills_details_and_click_get_all_customer_button() {
    	driver.findElement(By.xpath("/html/body/div/div[4]/button")).click();
    }

    @Then("validate All the Customer Details Fetched Successfully")
    public void validate_all_customer_details_fetched_successfully() {
    	driver.findElement(By.id("customerList"));
		wait(1000);
    }
    public void wait(int msec) {
		try {
			Thread.sleep(msec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



	