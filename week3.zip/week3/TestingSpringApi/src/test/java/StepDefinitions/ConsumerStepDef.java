package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ConsumerStepDef {

	@Given("the user is on the API page and click on Consumer button")
	public void the_user_is_on_the_api_page_and_click_on_consumer_button() {
		
	}

	@When("the user fills the details and click create order")
	public void the_user_fills_the_details_and_click_create_order() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("validate order created successfully")
	public void validate_order_created_successfully() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("the user is on the API page and click on the Consumer button")
	public void the_user_is_on_the_api_page_and_click_on_the_consumer_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("the user fills the details and click on the update order")
	public void the_user_fills_the_details_and_click_on_the_update_order() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("validate order updated Successfully")
	public void validate_order_updated_successfully() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("the user is on the API page  and click on Get Orders based on customerID")
	public void the_user_is_on_the_api_page_and_click_on_get_orders_based_on_customer_id() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("the user fills the details and click on Get orders")
	public void the_user_fills_the_details_and_click_on_get_orders() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("validate by showing all the orders.")
	public void validate_by_showing_all_the_orders() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("the user is on the API page  and click on Get Orders based on OrderId")
	public void the_user_is_on_the_api_page_and_click_on_get_orders_based_on_order_id() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

}
