package StepDefinitions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.cucumber.java.en.Then;

public class ServiceStepDef {

	public WebDriver driver;
	public Alert alert;
    @Given("the user is on the Main page and click serviceProvision button")
    public void user_on_main_page_and_click_service_provision_button() {
    	WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Service Provision")).click();
    }

    @When("the user fills the details and click Provision Service button")
    public void user_fills_details_and_click_provision_service_button() {
    	driver.findElement(By.id("serviceName")).sendKeys("tracking");
		wait(1000);
		driver.findElement(By.id("connectionId")).sendKeys("357");
		wait(2000);
		driver.findElement(By.xpath("//*[@id=\"provisionServiceForm\"]/button")).click();
    }

    @Then("validate Service provisioned successfully")
    public void validate_service_provisioned_successfully() {
    	driver.findElement(By.xpath("//*[@id=\"provisionMessage\"]"));
    }

   @When("the user fills the details and click Test QoS button")
    public void user_fills_details_and_click_test_qos_button() {
	   driver.findElement(By.id("testConnectionId")).sendKeys("357");
		wait(3000);
		driver.findElement(By.xpath("//*[@id=\"testQoSForm\"]/button")).click();
   }

    @Then("validate QoS Test Successful")
   public void validate_qos_test_successful() {
 
    	driver.findElement(By.xpath("//*[@id=\"testQoSMessage\"]"));
    	
   }

    @When("the user fills the details and click Disable Service button")
    public void user_fills_details_and_click_disable_service_button() {
    	driver.findElement(By.id("disableConnectionId")).sendKeys("357");
		wait(1000);
		driver.findElement(By.xpath("//*[@id=\"disableServiceForm\"]/button")).click();
    }

    @Then("validate Service disabled successfully")
    public void validate_service_disabled_successfully() {
    	driver.findElement(By.xpath("//*[@id=\"disableMessage\"]"));
    }

    @When("the user fills the details and click Hold Service button")
    public void user_fills_details_and_click_hold_service_button() {
    	driver.findElement(By.id("holdConnectionId")).sendKeys("357");
		wait(1000);
		driver.findElement(By.xpath("//*[@id=\"holdServiceForm\"]/button")).click();
    }

    @Then("validate Service put on hold successfully")
    public void validate_service_put_on_hold_successfully() {
    	driver.findElement(By.xpath("//*[@id=\"holdMessage\"]"));
    }

    @When("the user fills the details and click Resume Service button")
    public void user_fills_details_and_click_resume_service_button() {
    	driver.findElement(By.id("resumeConnectionId")).sendKeys("357");
		wait(1000);
		driver.findElement(By.xpath("//*[@id=\"resumeServiceForm\"]/button")).click();
    }

    @Then("validate Service resumed successfully")
    public void validate_service_resumed_successfully() {
    	driver.findElement(By.xpath("//*[@id=\"resumeMessage\"]"));
    }
    public void wait(int msec) {
		try {
			Thread.sleep(msec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
