package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.cucumber.java.en.Then;

public class OrderEnterpriseStepDef {
	public WebDriver driver;
	public Alert alert;

	@Given("the user is on Main page and click OrderEnterpriseCustomer button")
	public void user_on_main_page_and_click_order_enterprise_customer_button() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Order Enterprise Customer")).click();
	}

	@When("the user fills the details and click create order button")
	public void user_fills_details_and_click_create_order_button() {
		driver.findElement(By.id("customerId")).sendKeys("2102");
		wait(1000);
		driver.findElement(By.id("orderId")).sendKeys("1111");
		wait(1000);
		driver.findElement(By.id("productName")).sendKeys("mobile");
		wait(1000);
		driver.findElement(By.id("amount")).sendKeys("20000");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div[1]/button")).click();
	}

	@Then("validate order is created successfully")
	public void validate_order_created_successfully() {
		alert = driver.switchTo().alert();
		wait(4000);
		String actResult = alert.getText();
		Assert.assertEquals(actResult, "Order created successfully:");
		wait(3000);
		alert.accept();
		driver.findElement(By.id("orderList"));
	}

	@When("the user fills the details and click Update order button")
	public void user_fills_details_and_click_update_order_button() {
		driver.findElement(By.id("updateCustomerId")).sendKeys("2102");
		wait(1000);
		driver.findElement(By.id("updateOrderId")).sendKeys("1111");
		wait(1000);
		driver.findElement(By.id("updateProductName")).sendKeys("redmimobile");
		wait(1000);
		driver.findElement(By.id("updateAmount")).sendKeys("20000");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div[2]/button")).click();
	}

	@Then("validate product updated successfully")
	public void validate_product_updated_successfully() {
		alert = driver.switchTo().alert();
		wait(2000);
		String actResult = alert.getText();
		Assert.assertEquals(actResult, "Order updated successfully");
		wait(3000);
		alert.accept();
		driver.findElement(By.id("orderList"));
	}

	@When("the user fills the details and click Get Orders button")
	public void user_fills_details_and_click_get_orders_button() {
		driver.findElement(By.id("getCustomerId")).sendKeys("2102");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div[3]/button")).click();
	}

	@Then("validate orders are displayed successfully")
	public void validate_orders_displayed_successfully() {
		driver.findElement(By.id("orderList"));
	}

	@When("the user fills the details and click on Get Order button")
	public void user_fills_details_and_click_get_order_button() {
		driver.findElement(By.id("getCustomerId")).sendKeys("2102");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div[3]/button")).click();
		driver.findElement(By.id("getOrderId")).sendKeys("1111");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div[4]/button")).click();
	}

	@Then("validate order is displayed successfully")
	public void validate_order_displayed_successfully() {
		driver.findElement(By.id("orderList"));
	}

	public void wait(int msec) {
		try {
			Thread.sleep(msec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
