package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CustomerStepDef {
	public WebDriver driver;
	public Alert alert;
	@Given("the user is on the API page and click on Consumer button")
	public void the_user_is_on_the_api_page_and_click_on_consumer_button() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Consumer Customer")).click();
    }
	@When("the user fills the details and click create order")
	public void the_user_fills_the_details_and_click_create_order() {
		driver.findElement(By.id("customerId")).sendKeys("19");
		wait(1000);
		driver.findElement(By.id("orderId")).sendKeys("18");
		wait(1000);
		driver.findElement(By.id("status")).sendKeys("ioppp");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[1]/div/button")).click();
    }
	@Then("validate order created successfully")
	public void validate_order_created_successfully() {

    	alert = driver.switchTo().alert();
    	String actResult = alert.getText();
    	Assert.assertEquals(actResult, "Order created successfully.");
    	wait(3000);
    	alert.accept();
    }

	@Given("the user is on the API page and click on the Consumer button")
	public void the_user_is_on_the_api_page_and_click_on_the_consumer_button() {
		wait(3000);
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Consumer Customer")).click();
    }

	@When("the user fills the details and click on the update order")
	public void the_user_fills_the_details_and_click_on_the_update_order() {
		driver.findElement(By.id("updateCustomerId")).sendKeys("19");
		wait(1000);
		driver.findElement(By.id("updateOrderId")).sendKeys("18");
		wait(1000);
		driver.findElement(By.id("updateStatus")).sendKeys("yuioppp");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[2]/div/button")).click();
    }

	@Then("validate order updated Successfully")
	public void validate_order_updated_successfully() {
		alert = driver.switchTo().alert();
    	String actResult = alert.getText();
    	Assert.assertEquals(actResult, "Order updated successfully.");
    	wait(3000);
    	alert.accept();
    }
	
	@Given("the user is on the API page  and click on Get Orders based on customerID")
	public void the_user_is_on_the_api_page_and_click_on_get_orders_based_on_customer_id() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Consumer Customer")).click();
    }

	@When("the user fills the details and click on Get orders by customerID")
	public void the_user_fills_the_details_and_click_on_get_orders_by_customer_id() {
		driver.findElement(By.id("getCustomerId")).sendKeys("19");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[3]/div/button")).click();
    }
	@Then("validate by showing all the orders of particular customerID.")
	public void validate_by_showing_all_the_orders_of_particular_customer_id() {
		driver.findElement(By.id("orderList"));
    }

	@Given("the user is on the API page  and click on Get Orders based on OrderId")
	public void the_user_is_on_the_api_page_and_click_on_get_orders_based_on_order_id() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Consumer Customer")).click();
    }


	@When("the user fills the details and click on Get orders by orderID")
	public void the_user_fills_the_details_and_click_on_get_orders_by_order_id() {
		driver.findElement(By.id("getOrderCustomerId")).sendKeys("19");
		wait(1000);
		driver.findElement(By.id("getOrderId")).sendKeys("18");
		wait(1000);
		driver.findElement(By.xpath("/html/body/div/div[4]/div/button")).click();
    }

	@Then("validate by showing the particular order.")
	public void validate_by_showing_the_particular_order() {
		driver.findElement(By.id("orderList"));
    }
	public void wait(int msec) {
		  try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
}

	