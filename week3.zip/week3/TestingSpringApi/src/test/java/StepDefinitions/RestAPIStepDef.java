package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class RestAPIStepDef {

	public WebDriver driver;
	public Alert alert;
	
	@Given("the user in on Main page and click Catalog button")
	public void the_user_in_on_main_page_and_click_catalog_button() {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
	    driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Main.html");
		wait(2000);
		driver.findElement(By.linkText("Catalog API")).click();
	}

	@When("the user fills the details and click Create Product button")
	public void the_user_fills_the_details_and_click_create_product_button() {
		driver.findElement(By.id("productId")).sendKeys("1");
		wait(1000);
		driver.findElement(By.id("productName")).sendKeys("laptop");
		wait(1000);
		driver.findElement(By.id("productDescription")).sendKeys("laptop desc");
		wait(1000);
		driver.findElement(By.id("productPrice")).sendKeys("2000");
		wait(1000);
		driver.findElement(By.xpath("//*[@id=\"createProductForm\"]/button")).click();
		
	}

	@Then("validate Product created successfully")
	public void validate_product_created_successfully() {
	alert = driver.switchTo().alert();
	String actResult = alert.getText();
	Assert.assertEquals(actResult, "Product created successfully.");
	alert.accept();
	}

	@When("the user fills the details and click Update Product button")
	public void the_user_fills_the_details_and_click_update_product_button() {
		driver.findElement(By.id("updateProductId")).sendKeys("12");
		wait(1000);
		driver.findElement(By.id("updatedProductName")).sendKeys("laptop update");
		wait(1000);
		driver.findElement(By.id("updatedProductDescription")).sendKeys("laptop desc update");
		wait(1000);
		driver.findElement(By.id("updatedProductPrice")).sendKeys("2001");
		wait(1000);
		driver.findElement(By.xpath("//*[@id=\"updateProductForm\"]/button")).click();
	}

	@Then("validate Product updated successfully")
	public void validate_product_updated_successfully() {
		
		alert = driver.switchTo().alert();
		String actResult = alert.getText();
		Assert.assertEquals(actResult, "Product updated successfully.");
		alert.accept();
	}

	@When("the user fills the details and click Delete button")
	public void the_user_fills_the_details_and_click_delete_button() {
		driver.findElement(By.xpath("//*[@id=\"productList\"]/li/button[2]")).click();
		
	}

	@Then("validate Product deleted successfully")
	public void validate_product_deleted_successfully() {
		alert = driver.switchTo().alert();
		wait(2000);
		alert.accept();
		String actResult = alert.getText();
		Assert.assertEquals(actResult, "Product deleted successfully.");
		wait(2000);
		alert.accept();
		
	}

	@Then("validate all the Products displayed successfully")
	public void validate_all_the_products_displayed_successfully() {
		String actResult = driver.findElement(By.xpath("//*[@id=\"productList\"]/li/button[1]")).getText();
		Assert.assertEquals(actResult, "Edit");
		wait(2000);
	}
	
	public void wait(int msec) {
		try {
			Thread.sleep(msec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
