package webDriver;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class verifyTest {
	
	WebDriver driver;
	@Test
	void test() {
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		assertEquals(driver.getTitle(),"Google");
		
		
		//fail("Not yet implemented");
	}

}
