package com.verizon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Customer;
import com.verizon.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@GetMapping("/customer")
	public List<Customer> getCustomerDetails() {  
		
		List<Customer> customer1=customerService.getAllCustomers(); 
		return customer1;
	}

	@PostMapping("/customer") 
	public String  addCustomerDetails(@RequestBody	Customer customer) {
		return customerService.addCustomer(customer);
		}
	
	@PutMapping("/customer/{cId}") 
	public Customer updateCustomerDetails(@PathVariable("cId") Integer cId,@RequestBody Customer customer) {
		return customerService.updateCustomer(cId, customer);
		}
	
	@DeleteMapping("/customer/{cId}") 
	public Customer deleteCustomerDetails(@PathVariable("cId") Integer cId) {
		return customerService.deleteCustomer(cId);
		}
	
	
}
