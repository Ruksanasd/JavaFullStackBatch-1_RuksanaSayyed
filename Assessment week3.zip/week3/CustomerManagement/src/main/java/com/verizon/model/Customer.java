package com.verizon.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity

public class Customer {

	@Id
	Integer cId;
	@Column
	String cName;
	String cEmail;
	
	public Customer() {
		
	}
	
	public Customer(Integer cId, String cName, String cEmail) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.cEmail = cEmail;
	}

	@Override
	public String toString() {
		return "CustomerManagement [cId=" + cId + ", cName=" + cName + ", cEmail=" + cEmail + "]";
	}

	public Integer getcId() {
		return cId;
	}

	public void setcId(Integer cId) {
		this.cId = cId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	
}
