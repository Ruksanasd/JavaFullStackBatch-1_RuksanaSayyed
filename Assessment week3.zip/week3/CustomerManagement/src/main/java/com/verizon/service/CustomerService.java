package com.verizon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;

@Service
public class CustomerService {
		@Autowired
		CustomerDao customerDao;
		
		public String addCustomer(Customer customer) 
		{
			customerDao.save(customer);
			//
			return "New customer is added";
		}
		
		public List<Customer> getAllCustomers() 
		{
			List<Customer> customer=customerDao.findAll();
			return customer;
		}
		
		public Customer updateCustomer(Integer cId,Customer customer) 
		{
			Customer customer1=customerDao.findById(cId).get();
			customer1.setcEmail(customer.getcEmail());
			return customer1;
			
		}
		public Customer deleteCustomer(Integer cId) 
		{
			Customer customer1=customerDao.findById(cId).get();
			if(customer1!=null)
				customerDao.deleteById(cId);
			return customer1;
		}


}
